from django.contrib import admin
from .models import Category, Product, StoreSettings


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ("name", "slug")
    search_fields = ("name", "slug")
    prepopulated_fields = {"slug": ("name",)}


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ("name", "category", "price", "stock", "is_active", "featured", "updated_at")
    list_filter = ("category", "condition", "size", "is_active", "featured")
    search_fields = ("name", "description", "slug")
    prepopulated_fields = {"slug": ("name",)}
    list_editable = ("price", "stock", "is_active", "featured")


@admin.register(StoreSettings)
class StoreSettingsAdmin(admin.ModelAdmin):
    list_display = ("store_name", "phone", "email", "updated_at")
