from django.db import migrations, models


def fill_slugs(apps, schema_editor):
    from django.utils.text import slugify
    Category = apps.get_model("shop", "Category")
    Product = apps.get_model("shop", "Product")
    used = set()
    for obj in Category.objects.order_by("id"):
        base = slugify(obj.slug or obj.name, allow_unicode=True) or f"category-{obj.pk}"
        slug = base
        i = 2
        while slug in used:
            slug = f"{base}-{i}"
            i += 1
        obj.slug = slug
        obj.save(update_fields=["slug"])
        used.add(slug)
    used = set()
    for obj in Product.objects.order_by("id"):
        base = slugify(obj.slug or obj.name, allow_unicode=True) or f"product-{obj.pk}"
        slug = base
        i = 2
        while slug in used:
            slug = f"{base}-{i}"
            i += 1
        obj.slug = slug
        obj.save(update_fields=["slug"])
        used.add(slug)


class Migration(migrations.Migration):
    dependencies = [("shop", "0001_initial")]
    operations = [
        migrations.AlterField(model_name="category", name="slug", field=models.SlugField(blank=True, max_length=120, unique=True)),
        migrations.AlterField(model_name="product", name="slug", field=models.SlugField(blank=True, max_length=220, unique=True)),
        migrations.CreateModel(
            name="StoreSettings",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("store_name", models.CharField(default="SECOND STYLE", max_length=150)),
                ("tagline", models.CharField(blank=True, max_length=255)),
                ("phone", models.CharField(blank=True, max_length=30)),
                ("email", models.EmailField(blank=True, max_length=254)),
                ("line_id", models.CharField(blank=True, max_length=100)),
                ("facebook", models.URLField(blank=True)),
                ("instagram", models.URLField(blank=True)),
                ("address", models.TextField(blank=True)),
                ("shipping_note", models.TextField(blank=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={"verbose_name": "ตั้งค่าร้าน", "verbose_name_plural": "ตั้งค่าร้าน"},
        ),
        migrations.RunPython(fill_slugs, migrations.RunPython.noop),
    ]
