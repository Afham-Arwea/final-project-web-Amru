from decimal import Decimal
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.shortcuts import get_object_or_404, redirect, render
from django.core.paginator import Paginator
from .models import Category, Product
from orders.models import Order, OrderItem

def home(request):
    featured = Product.objects.filter(is_active=True, featured=True)[:8]
    latest = Product.objects.filter(is_active=True)[:8]
    categories = Category.objects.all()
    return render(request, "shop/home.html", {"featured": featured, "latest": latest, "categories": categories})

def product_list(request):
    products = Product.objects.filter(is_active=True)
    q = request.GET.get("q", "").strip()
    category = request.GET.get("category", "")
    size = request.GET.get("size", "")
    sort = request.GET.get("sort", "newest")

    if q:
        products = products.filter(name__icontains=q) | products.filter(description__icontains=q)
    if category:
        products = products.filter(category__slug=category)
    if size:
        products = products.filter(size=size)

    if sort == "price_low":
        products = products.order_by("price")
    elif sort == "price_high":
        products = products.order_by("-price")
    else:
        products = products.order_by("-created_at")

    products = products.distinct()
    paginator = Paginator(products, 12)
    page_obj = paginator.get_page(request.GET.get("page", 1))

    return render(request, "shop/product_list.html", {
        "products": page_obj.object_list,
        "page_obj": page_obj,
        "paginator": paginator,
        "total_products": paginator.count,
        "categories": Category.objects.all(),
        "q": q,
        "selected_category": category,
        "selected_size": size,
        "selected_sort": sort,
        "sizes": Product.SIZE_CHOICES,
    })

def product_detail(request, slug):
    product = get_object_or_404(Product, slug=slug, is_active=True)
    related = Product.objects.filter(category=product.category, is_active=True).exclude(pk=product.pk)[:4]
    return render(request, "shop/product_detail.html", {"product": product, "related": related})

def _cart_data(request):
    cart = request.session.get("cart", {})
    items, total, count = [], Decimal("0.00"), 0
    products = Product.objects.filter(pk__in=cart.keys(), is_active=True)
    for product in products:
        qty = int(cart.get(str(product.pk), 0))
        qty = min(qty, product.stock)
        if qty <= 0:
            continue
        subtotal = product.price * qty
        items.append({"product": product, "quantity": qty, "subtotal": subtotal})
        total += subtotal
        count += qty
    return cart, items, total, count

def cart(request):
    _, items, total, count = _cart_data(request)
    return render(request, "shop/cart.html", {"items": items, "total": total, "count": count})

def cart_add(request, product_id):
    product = get_object_or_404(Product, pk=product_id, is_active=True)
    if product.stock <= 0:
        messages.error(request, "สินค้าชิ้นนี้หมดแล้ว")
        return redirect(product.get_absolute_url())
    cart = request.session.get("cart", {})
    key = str(product.pk)
    current = int(cart.get(key, 0))
    cart[key] = min(current + 1, product.stock)
    request.session["cart"] = cart
    request.session.modified = True
    messages.success(request, "เพิ่มสินค้าลงตะกร้าแล้ว")
    return redirect("shop:cart")

def cart_update(request, product_id):
    if request.method != "POST":
        return redirect("shop:cart")
    product = get_object_or_404(Product, pk=product_id, is_active=True)
    qty = max(0, int(request.POST.get("quantity", 0)))
    cart = request.session.get("cart", {})
    if qty == 0:
        cart.pop(str(product.pk), None)
    else:
        cart[str(product.pk)] = min(qty, product.stock)
    request.session["cart"] = cart
    request.session.modified = True
    return redirect("shop:cart")

def cart_remove(request, product_id):
    cart = request.session.get("cart", {})
    cart.pop(str(product_id), None)
    request.session["cart"] = cart
    request.session.modified = True
    return redirect("shop:cart")

@login_required
@transaction.atomic
def checkout(request):
    _, items, total, count = _cart_data(request)
    if not items:
        messages.warning(request, "กรุณาเพิ่มสินค้าลงตะกร้าก่อน")
        return redirect("shop:product_list")

    if request.method == "POST":
        full_name = request.POST.get("full_name", "").strip()
        phone = request.POST.get("phone", "").strip()
        address = request.POST.get("address", "").strip()
        note = request.POST.get("note", "").strip()
        if not full_name or not phone or not address:
            messages.error(request, "กรุณากรอกชื่อ เบอร์โทร และที่อยู่ให้ครบ")
            return render(request, "shop/checkout.html", {"items": items, "total": total, "count": count})
        order = Order.objects.create(
            user=request.user,
            full_name=full_name,
            phone=phone,
            address=address,
            note=note,
            total=total,
            payment_method="cod",
        )
        for item in items:
            product = Product.objects.select_for_update().get(pk=item["product"].pk)
            if product.stock < item["quantity"]:
                messages.error(request, f"สินค้า {product.name} มีจำนวนไม่พอ")
                raise ValueError("Stock changed during checkout")
            OrderItem.objects.create(order=order, product=product, price=product.price, quantity=item["quantity"])
            product.stock -= item["quantity"]
            product.save(update_fields=["stock", "updated_at"])
        request.session["cart"] = {}
        request.session.modified = True
        return redirect("orders:success", order_id=order.pk)

    return render(request, "shop/checkout.html", {"items": items, "total": total, "count": count})

def about(request):
    return render(request, "shop/about.html")

def contact(request):
    return render(request, "shop/contact.html")
