SECOND STYLE — ADMIN READY

สิ่งที่ตั้งค่าไว้:
- ปุ่ม ⚙ Admin แสดงบนหน้าเว็บเฉพาะ user.is_staff เท่านั้น
- กดปุ่ม Admin จากหน้าร้านไป /dashboard/
- Dashboard จำกัดด้วย staff_member_required
- Admin จัดการสินค้า หมวดหมู่ ลูกค้า คำสั่งซื้อ และตั้งค่าร้าน
- มีลิงก์กลับหน้าร้านจาก Dashboard
- บัญชีที่ไม่ใช่ Staff จะเข้า Admin Dashboard ไม่ได้ แม้พยายามเข้าลิงก์ตรง
- StaffLoginForm ตรวจสิทธิ์ is_staff โดยตรง

หลังแตก ZIP:
python manage.py migrate
python manage.py runserver

จากนั้นเปิด:
http://127.0.0.1:8000/

หมายเหตุ:
บัญชี Admin/Superuser ที่สร้างไว้ต้องมี is_staff=True ซึ่ง Django superuser จะมีให้อัตโนมัติ
