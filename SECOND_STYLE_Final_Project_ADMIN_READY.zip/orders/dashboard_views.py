from django.contrib import messages
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib.auth import get_user_model
from django.contrib.auth.views import LoginView, LogoutView
from django.db.models import Sum
from django.shortcuts import get_object_or_404, redirect, render

from shop.models import Product, Category, StoreSettings
from .dashboard_forms import ProductForm, CategoryForm, StaffLoginForm, CustomerForm, StoreSettingsForm
from .models import Order


class StaffLoginView(LoginView):
    template_name = "dashboard/login.html"
    authentication_form = StaffLoginForm
    redirect_authenticated_user = True

    def get_success_url(self):
        return "/dashboard/"


def dashboard_login(request):
    return StaffLoginView.as_view()(request)


def dashboard_logout(request):
    return LogoutView.as_view(next_page="/dashboard/login/")(request)


def _context(**extra):
    base = {
        'product_count': Product.objects.count(),
        'category_count': Category.objects.count(),
        'order_count': Order.objects.count(),
        'customer_count': get_user_model().objects.filter(is_staff=False).count(),
        'sales_total': Order.objects.exclude(status='cancelled').aggregate(v=Sum('total'))['v'] or 0,
        'pending_count': Order.objects.filter(status='pending').count(),
    }
    base.update(extra)
    return base


@staff_member_required(login_url="/dashboard/login/")
def dashboard(request):
    recent = Order.objects.select_related('user').all()[:8]
    return render(request, 'dashboard/home.html', _context(recent=recent))


@staff_member_required(login_url="/dashboard/login/")
def dashboard_products(request):
    products = Product.objects.select_related('category').all()
    q = request.GET.get('q', '').strip()
    if q:
        products = products.filter(name__icontains=q)
    return render(request, 'dashboard/products.html', _context(products=products, q=q))


@staff_member_required(login_url="/dashboard/login/")
def dashboard_product_create(request):
    form = ProductForm(request.POST or None, request.FILES or None)
    if form.is_valid():
        form.save()
        messages.success(request, 'เพิ่มสินค้าเรียบร้อยแล้ว')
        return redirect('dashboard:products')
    return render(request, 'dashboard/product_form.html', _context(form=form, page_title='เพิ่มสินค้า', action='เพิ่มสินค้า'))


@staff_member_required(login_url="/dashboard/login/")
def dashboard_product_edit(request, pk):
    product = get_object_or_404(Product, pk=pk)
    form = ProductForm(request.POST or None, request.FILES or None, instance=product)
    if form.is_valid():
        form.save()
        messages.success(request, 'บันทึกข้อมูลสินค้าเรียบร้อยแล้ว')
        return redirect('dashboard:products')
    return render(request, 'dashboard/product_form.html', _context(form=form, product=product, page_title='แก้ไขสินค้า', action='บันทึกการแก้ไข'))


@staff_member_required(login_url="/dashboard/login/")
def dashboard_product_delete(request, pk):
    product = get_object_or_404(Product, pk=pk)
    if request.method == 'POST':
        product.delete()
        messages.success(request, 'ลบสินค้าเรียบร้อยแล้ว')
    return redirect('dashboard:products')


@staff_member_required(login_url="/dashboard/login/")
def dashboard_categories(request):
    categories = Category.objects.all()
    return render(request, 'dashboard/categories.html', _context(categories=categories))


@staff_member_required(login_url="/dashboard/login/")
def dashboard_category_create(request):
    form = CategoryForm(request.POST or None)
    if form.is_valid():
        form.save()
        messages.success(request, 'เพิ่มหมวดหมู่เรียบร้อยแล้ว')
        return redirect('dashboard:categories')
    return render(request, 'dashboard/category_form.html', _context(form=form, page_title='เพิ่มหมวดหมู่', action='เพิ่มหมวดหมู่'))


@staff_member_required(login_url="/dashboard/login/")
def dashboard_category_edit(request, pk):
    category = get_object_or_404(Category, pk=pk)
    form = CategoryForm(request.POST or None, instance=category)
    if form.is_valid():
        form.save()
        messages.success(request, 'บันทึกหมวดหมู่เรียบร้อยแล้ว')
        return redirect('dashboard:categories')
    return render(request, 'dashboard/category_form.html', _context(form=form, category=category, page_title='แก้ไขหมวดหมู่', action='บันทึกการแก้ไข'))


@staff_member_required(login_url="/dashboard/login/")
def dashboard_category_delete(request, pk):
    category = get_object_or_404(Category, pk=pk)
    if request.method == 'POST':
        if category.products.exists():
            messages.error(request, 'หมวดหมู่นี้มีสินค้าอยู่ จึงยังลบไม่ได้')
        else:
            category.delete()
            messages.success(request, 'ลบหมวดหมู่เรียบร้อยแล้ว')
    return redirect('dashboard:categories')


@staff_member_required(login_url="/dashboard/login/")
def dashboard_orders(request):
    orders = Order.objects.select_related('user').prefetch_related('items__product').all()
    status = request.GET.get('status', '')
    if status:
        orders = orders.filter(status=status)
    return render(request, 'dashboard/orders.html', _context(orders=orders, selected_status=status, status_choices=Order.STATUS_CHOICES))


@staff_member_required(login_url="/dashboard/login/")
def dashboard_order_edit(request, pk):
    order = get_object_or_404(Order, pk=pk)
    if request.method == 'POST':
        status = request.POST.get('status')
        if status in dict(Order.STATUS_CHOICES):
            order.status = status
            order.save(update_fields=['status', 'updated_at'])
            messages.success(request, f'อัปเดตสถานะ Order #{order.pk} แล้ว')
        return redirect('dashboard:orders')
    return render(request, 'dashboard/order_detail.html', _context(order=order, status_choices=Order.STATUS_CHOICES))


@staff_member_required(login_url="/dashboard/login/")
def dashboard_customers(request):
    User = get_user_model()
    customers = User.objects.filter(is_staff=False).order_by('-date_joined')
    return render(request, 'dashboard/customers.html', _context(customers=customers))

@staff_member_required(login_url="/dashboard/login/")
def dashboard_customer_edit(request, pk):
    User = get_user_model()
    customer = get_object_or_404(User, pk=pk, is_staff=False)
    form = CustomerForm(request.POST or None, instance=customer)
    if form.is_valid():
        form.save()
        messages.success(request, f'บันทึกข้อมูลลูกค้า {customer.username} เรียบร้อยแล้ว')
        return redirect('dashboard:customers')
    return render(request, 'dashboard/customer_form.html', _context(customer=customer, form=form, page_title='แก้ไขข้อมูลลูกค้า', action='บันทึกการแก้ไข'))

@staff_member_required(login_url="/dashboard/login/")
def dashboard_customer_delete(request, pk):
    User = get_user_model()
    customer = get_object_or_404(User, pk=pk, is_staff=False)
    if request.method == 'POST':
        customer.delete()
        messages.success(request, 'ลบบัญชีลูกค้าเรียบร้อยแล้ว')
    return redirect('dashboard:customers')


@staff_member_required(login_url="/dashboard/login/")
def dashboard_store_settings(request):
    obj = StoreSettings.get_solo()
    form = StoreSettingsForm(request.POST or None, instance=obj)
    if form.is_valid():
        form.save()
        messages.success(request, "บันทึกข้อมูลร้านเรียบร้อยแล้ว")
        return redirect("dashboard:store_settings")
    return render(request, "dashboard/store_settings.html", _context(form=form, settings_obj=obj, page_title="ตั้งค่าร้าน"))
