from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, render
from .models import Order

@login_required
def my_orders(request):
    orders = Order.objects.filter(user=request.user).prefetch_related("items__product")
    return render(request, "orders/my_orders.html", {"orders": orders})

@login_required
def order_detail(request, order_id):
    order = get_object_or_404(Order.objects.prefetch_related("items__product"), pk=order_id, user=request.user)
    return render(request, "orders/order_detail.html", {"order": order})

@login_required
def order_success(request, order_id):
    order = get_object_or_404(Order, pk=order_id, user=request.user)
    return render(request, "orders/success.html", {"order": order})
