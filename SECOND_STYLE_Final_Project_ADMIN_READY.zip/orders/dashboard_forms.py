from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import AuthenticationForm
from shop.models import Product, Category, StoreSettings
from accounts.models import CustomerProfile

User = get_user_model()

class StaffLoginForm(AuthenticationForm):
    username = forms.CharField(label="Username")
    password = forms.CharField(label="Password", widget=forms.PasswordInput)

    def confirm_login_allowed(self, user):
        super().confirm_login_allowed(user)
        if not user.is_staff:
            raise forms.ValidationError(
                "บัญชีนี้ไม่มีสิทธิ์เข้า Admin กรุณาใช้บัญชี Staff/Admin",
                code="not_staff",
            )

class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ["name", "category", "description", "price", "size", "condition", "stock", "image", "image_url", "is_active", "featured"]
        widgets = {"description": forms.Textarea(attrs={"rows": 5})}

class CategoryForm(forms.ModelForm):
    class Meta:
        model = Category
        fields = ["name", "slug", "description"]
        widgets = {"description": forms.Textarea(attrs={"rows": 4})}

class CustomerForm(forms.ModelForm):
    phone = forms.CharField(label="เบอร์โทร", required=False, max_length=30)
    address = forms.CharField(label="ที่อยู่", required=False, widget=forms.Textarea(attrs={"rows": 4}))
    new_password = forms.CharField(label="รหัสผ่านใหม่", required=False, widget=forms.PasswordInput, help_text="เว้นว่างไว้ถ้าไม่ต้องการเปลี่ยน")

    class Meta:
        model = User
        fields = ["username", "email", "first_name", "last_name", "is_active", "phone", "address", "new_password"]
        labels = {
            "username": "Username", "email": "อีเมล", "first_name": "ชื่อ", "last_name": "นามสกุล", "is_active": "เปิดใช้งานบัญชี"
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        profile, _ = CustomerProfile.objects.get_or_create(user=self.instance)
        self.fields["phone"].initial = profile.phone
        self.fields["address"].initial = profile.address

    def save(self, commit=True):
        user = super().save(commit=commit)
        if commit:
            profile, _ = CustomerProfile.objects.get_or_create(user=user)
            profile.phone = self.cleaned_data.get("phone", "")
            profile.address = self.cleaned_data.get("address", "")
            profile.save()
            password = self.cleaned_data.get("new_password")
            if password:
                user.set_password(password)
                user.save(update_fields=["password"])
        return user

class StoreSettingsForm(forms.ModelForm):
    class Meta:
        model = StoreSettings
        fields = ["store_name", "tagline", "phone", "email", "line_id", "facebook", "instagram", "address", "shipping_note"]
        widgets = {"address": forms.Textarea(attrs={"rows": 4}), "shipping_note": forms.Textarea(attrs={"rows": 4})}
