from django.urls import path
from . import dashboard_views

app_name = 'dashboard'

urlpatterns = [
    path("login/", dashboard_views.dashboard_login, name="login"),
    path("logout/", dashboard_views.dashboard_logout, name="logout"),
    path('', dashboard_views.dashboard, name='home'),
    path('products/', dashboard_views.dashboard_products, name='products'),
    path('products/new/', dashboard_views.dashboard_product_create, name='product_create'),
    path('products/<int:pk>/edit/', dashboard_views.dashboard_product_edit, name='product_edit'),
    path('products/<int:pk>/delete/', dashboard_views.dashboard_product_delete, name='product_delete'),
    path('categories/', dashboard_views.dashboard_categories, name='categories'),
    path('categories/new/', dashboard_views.dashboard_category_create, name='category_create'),
    path('categories/<int:pk>/edit/', dashboard_views.dashboard_category_edit, name='category_edit'),
    path('categories/<int:pk>/delete/', dashboard_views.dashboard_category_delete, name='category_delete'),
    path('orders/', dashboard_views.dashboard_orders, name='orders'),
    path('orders/<int:pk>/', dashboard_views.dashboard_order_edit, name='order_edit'),
    path('customers/', dashboard_views.dashboard_customers, name='customers'),
    path('customers/<int:pk>/edit/', dashboard_views.dashboard_customer_edit, name='customer_edit'),
    path('customers/<int:pk>/delete/', dashboard_views.dashboard_customer_delete, name='customer_delete'),
    path('store-settings/', dashboard_views.dashboard_store_settings, name='store_settings'),
]
