from django.contrib.auth.decorators import login_required
from django.urls import path
from . import views

app_name = "orders"

urlpatterns = [
    path("", login_required(views.my_orders), name="my_orders"),
    path("<int:order_id>/", login_required(views.order_detail), name="detail"),
    path("<int:order_id>/success/", login_required(views.order_success), name="success"),
]
