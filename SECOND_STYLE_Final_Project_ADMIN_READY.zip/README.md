# SECOND STYLE — Final Connected Django Project

โปรเจกต์ร้านเสื้อผ้ามือสองที่เชื่อม **หน้าร้าน + ลูกค้า + Admin + Django Database + REST API** เข้าด้วยกัน

## สิ่งที่เชื่อมกันจริง
- ลูกค้าสมัครสมาชิก → User + CustomerProfile ถูกบันทึกใน SQLite/Django
- ลูกค้าแก้ไขโปรไฟล์ → ข้อมูลเดียวกับที่ Admin เห็น
- Admin เพิ่ม/แก้ไขสินค้าและหมวดหมู่ → หน้าร้านใช้ข้อมูลจาก Database เดียวกัน
- ลูกค้าสั่งซื้อ → Order/OrderItem ถูกบันทึกใน Database → Admin เห็นและเปลี่ยนสถานะได้
- Admin แก้ข้อมูลร้าน → ใช้บนหน้า Contact และ context ของเว็บไซต์
- REST API อยู่ที่ `/api/` และใช้ Token Authentication

## ติดตั้งบน Mac
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
python seed_demo.py
python manage.py createsuperuser
python manage.py runserver
```

## URL หลัก
- ร้าน: http://127.0.0.1:8000/
- สมัครสมาชิก: http://127.0.0.1:8000/accounts/register/
- Login ลูกค้า: http://127.0.0.1:8000/accounts/login/
- Profile: http://127.0.0.1:8000/accounts/profile/
- Dashboard Admin: http://127.0.0.1:8000/dashboard/
- Django Admin: http://127.0.0.1:8000/admin/
- REST API: http://127.0.0.1:8000/api/

## หมายเหตุ
`runserver` เป็น development server ของ Django เหมาะสำหรับโปรเจกต์/การสาธิต ไม่ใช่ production deployment
