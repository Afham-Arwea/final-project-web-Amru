from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import UserCreationForm
from .models import CustomerProfile

User = get_user_model()


class RegisterForm(UserCreationForm):
    email = forms.EmailField(label="อีเมล", required=True)
    first_name = forms.CharField(label="ชื่อ", required=True, max_length=150)
    last_name = forms.CharField(label="นามสกุล", required=True, max_length=150)
    phone = forms.CharField(label="เบอร์โทร", required=True, max_length=30)
    address = forms.CharField(label="ที่อยู่", required=True, widget=forms.Textarea(attrs={"rows": 3}))

    class Meta:
        model = User
        fields = ["username", "email", "first_name", "last_name", "phone", "address", "password1", "password2"]

    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data["email"]
        user.first_name = self.cleaned_data["first_name"]
        user.last_name = self.cleaned_data["last_name"]
        if commit:
            user.save()
            CustomerProfile.objects.update_or_create(
                user=user,
                defaults={
                    "phone": self.cleaned_data["phone"],
                    "address": self.cleaned_data["address"],
                },
            )
        return user


class ProfileForm(forms.ModelForm):
    phone = forms.CharField(label="เบอร์โทร", required=False, max_length=30)
    address = forms.CharField(label="ที่อยู่", required=False, widget=forms.Textarea(attrs={"rows": 4}))

    class Meta:
        model = User
        fields = ["email", "first_name", "last_name"]
        labels = {"email": "อีเมล", "first_name": "ชื่อ", "last_name": "นามสกุล"}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        profile, _ = CustomerProfile.objects.get_or_create(user=self.instance)
        self.fields["phone"].initial = profile.phone
        self.fields["address"].initial = profile.address

    def save(self, commit=True):
        user = super().save(commit=commit)
        if commit:
            CustomerProfile.objects.update_or_create(
                user=user,
                defaults={"phone": self.cleaned_data.get("phone", ""), "address": self.cleaned_data.get("address", "")},
            )
        return user
