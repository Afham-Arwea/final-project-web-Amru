from django.conf import settings
from django.db import models


class CustomerProfile(models.Model):
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="customer_profile",
        null=True,
        blank=True,
    )
    phone = models.CharField(max_length=30, blank=True)
    address = models.TextField(blank=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "ข้อมูลลูกค้า"
        verbose_name_plural = "ข้อมูลลูกค้า"

    def __str__(self):
        return f"ข้อมูลลูกค้า: {self.user.username if self.user else '-'}"
