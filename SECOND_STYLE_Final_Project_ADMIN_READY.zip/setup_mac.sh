#!/bin/bash
set -e
cd "$(dirname "$0")"
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python manage.py migrate
python seed_demo.py
echo
echo "ติดตั้งเสร็จแล้ว"
echo "รันเว็บ: source .venv/bin/activate && python manage.py runserver"
echo "ลูกค้าทดลอง: demo / Demo12345!"
echo "สร้างแอดมิน: python manage.py createsuperuser"
