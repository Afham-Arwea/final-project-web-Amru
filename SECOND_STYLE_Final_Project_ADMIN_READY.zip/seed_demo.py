import os
import django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")
django.setup()

from django.contrib.auth import get_user_model
from shop.models import Category, Product, StoreSettings
from accounts.models import CustomerProfile

categories = [
    ("เสื้อยืด", "t-shirts", "เสื้อยืดมือสองคัดสภาพ"),
    ("เสื้อเชิ้ต", "shirts", "เสื้อเชิ้ตสไตล์คลาสสิก"),
    ("กางเกง", "pants", "กางเกงยีนส์และกางเกงแฟชั่น"),
    ("แจ็กเก็ต", "jackets", "แจ็กเก็ตและเสื้อคลุม"),
]
for name, slug, desc in categories:
    Category.objects.update_or_create(slug=slug, defaults={"name": name, "description": desc})

data = [
    ("Vintage Nike T-Shirt", "vintage-nike-t-shirt", "เสื้อยืด Nike วินเทจ มือสอง สภาพดี เหมาะกับลุค casual", 390, "L", "excellent", "t-shirts", "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=900&q=80"),
    ("Classic Denim Shirt", "classic-denim-shirt", "เสื้อเชิ้ตยีนส์ทรงคลาสสิก ใส่ได้หลายโอกาส", 450, "M", "good", "shirts", "https://images.unsplash.com/photo-1603252110481-7ba873bf42ab?auto=format&fit=crop&w=900&q=80"),
    ("Levi's Style Jeans", "levis-style-jeans", "กางเกงยีนส์มือสองทรงสวย เนื้อผ้าดี", 590, "L", "good", "pants", "https://images.unsplash.com/photo-1542272604-787c3835535d?auto=format&fit=crop&w=900&q=80"),
    ("Vintage Varsity Jacket", "vintage-varsity-jacket", "แจ็กเก็ตวินเทจ สไตล์ varsity", 890, "XL", "excellent", "jackets", "https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&w=900&q=80"),
    ("Minimal White Tee", "minimal-white-tee", "เสื้อยืดสีขาว basic ใส่ได้ทุกวัน", 250, "M", "good", "t-shirts", "https://images.unsplash.com/photo-1529139574466-a303027c1d8b?auto=format&fit=crop&w=900&q=80"),
    ("Oxford Casual Shirt", "oxford-casual-shirt", "เสื้อเชิ้ต Oxford มือสอง โทนสุภาพ", 420, "L", "good", "shirts", "https://images.unsplash.com/photo-1596755389378-c31d21fd1273?auto=format&fit=crop&w=900&q=80"),
]
for name, slug, desc, price, size, condition, cat_slug, image_url in data:
    Product.objects.update_or_create(slug=slug, defaults={"name": name, "description": desc, "price": price, "size": size, "condition": condition, "category": Category.objects.get(slug=cat_slug), "stock": 5, "image_url": image_url, "is_active": True, "featured": slug in ["vintage-nike-t-shirt", "vintage-varsity-jacket", "levis-style-jeans"]})

User = get_user_model()
demo, created = User.objects.get_or_create(username="demo")
demo.email = demo.email or "demo@example.com"
demo.first_name = demo.first_name or "Demo"
demo.last_name = demo.last_name or "Customer"
if created:
    demo.set_password("Demo12345!")
demo.save()
CustomerProfile.objects.update_or_create(user=demo, defaults={"phone": "0800000000", "address": "กรุงเทพมหานคร"})

StoreSettings.objects.update_or_create(pk=1, defaults={"store_name": "SECOND STYLE", "tagline": "Secondhand clothing, thoughtfully selected.", "phone": "08X-XXX-XXXX", "email": "hello@secondstyle.local", "line_id": "secondstyle", "address": "กรุงเทพมหานคร", "shipping_note": "จัดส่งทั่วประเทศ"})

print("Demo data ready.")
print("Customer: demo / Demo12345!")
print("Admin: run python manage.py createsuperuser")
