FIXED: accounts migration dependency now correctly uses settings.AUTH_USER_MODEL.
This resolves: ValueError: Dependency on unknown app: AUTH_USER_MODEL

After extracting:
1. python manage.py migrate
2. python manage.py createsuperuser
3. python seed_demo.py
4. python manage.py runserver
