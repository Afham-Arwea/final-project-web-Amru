from django.urls import include, path
from rest_framework.routers import DefaultRouter
from .views import CategoryViewSet, ProductViewSet, CustomerViewSet, OrderViewSet, MeAPIView, ApiLoginView, StoreSettingsAPIView

router = DefaultRouter()
router.register("categories", CategoryViewSet, basename="category")
router.register("products", ProductViewSet, basename="product")
router.register("customers", CustomerViewSet, basename="customer")
router.register("orders", OrderViewSet, basename="order")

urlpatterns = [
    path("login/", ApiLoginView.as_view(), name="login"),
    path("me/", MeAPIView.as_view(), name="me"),
    path("store-settings/", StoreSettingsAPIView.as_view(), name="store_settings"),
    path("", include(router.urls)),
]
