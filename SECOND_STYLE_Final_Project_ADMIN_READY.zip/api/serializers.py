from django.contrib.auth import get_user_model
from rest_framework import serializers
from shop.models import Category, Product, StoreSettings
from orders.models import Order, OrderItem
from accounts.models import CustomerProfile

User = get_user_model()

class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ["id", "name", "slug", "description"]

class ProductSerializer(serializers.ModelSerializer):
    category_name = serializers.CharField(source="category.name", read_only=True)
    display_image = serializers.CharField(read_only=True)
    class Meta:
        model = Product
        fields = ["id", "name", "slug", "category", "category_name", "description", "price", "size", "condition", "stock", "image", "image_url", "display_image", "is_active", "featured", "created_at", "updated_at"]
        read_only_fields = ["created_at", "updated_at", "display_image"]

class UserSerializer(serializers.ModelSerializer):
    order_count = serializers.IntegerField(source="orders.count", read_only=True)
    phone = serializers.CharField(source="customer_profile.phone", read_only=True)
    address = serializers.CharField(source="customer_profile.address", read_only=True)
    class Meta:
        model = User
        fields = ["id", "username", "email", "first_name", "last_name", "phone", "address", "is_active", "date_joined", "order_count"]
        read_only_fields = ["id", "username", "date_joined", "order_count"]

class OrderItemSerializer(serializers.ModelSerializer):
    product_name = serializers.CharField(source="product.name", read_only=True)
    subtotal = serializers.DecimalField(max_digits=12, decimal_places=2, read_only=True)
    class Meta:
        model = OrderItem
        fields = ["id", "product", "product_name", "price", "quantity", "subtotal"]

class OrderSerializer(serializers.ModelSerializer):
    items = OrderItemSerializer(many=True, read_only=True)
    username = serializers.CharField(source="user.username", read_only=True)
    class Meta:
        model = Order
        fields = ["id", "username", "full_name", "phone", "address", "note", "total", "status", "payment_method", "created_at", "updated_at", "items"]
        read_only_fields = ["id", "username", "total", "created_at", "updated_at", "items"]

class StoreSettingsSerializer(serializers.ModelSerializer):
    class Meta:
        model = StoreSettings
        fields = ["id", "store_name", "tagline", "phone", "email", "line_id", "facebook", "instagram", "address", "shipping_note", "updated_at"]
        read_only_fields = ["id", "updated_at"]
