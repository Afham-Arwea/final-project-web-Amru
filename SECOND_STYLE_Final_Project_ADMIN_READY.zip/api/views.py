from django.contrib.auth import get_user_model
from rest_framework import permissions, viewsets
from rest_framework.authtoken.views import ObtainAuthToken
from rest_framework.authtoken.models import Token
from rest_framework.response import Response
from rest_framework.views import APIView
from shop.models import Category, Product, StoreSettings
from orders.models import Order
from .serializers import CategorySerializer, ProductSerializer, UserSerializer, OrderSerializer, StoreSettingsSerializer

User = get_user_model()

class PublicReadAdminWrite(permissions.BasePermission):
    """Anyone can read catalog data; only staff can create/update/delete it."""
    def has_permission(self, request, view):
        if request.method in permissions.SAFE_METHODS:
            return True
        return bool(request.user and request.user.is_staff)

class CategoryViewSet(viewsets.ModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    permission_classes = [PublicReadAdminWrite]
    lookup_field = "slug"

class ProductViewSet(viewsets.ModelViewSet):
    queryset = Product.objects.select_related("category").all()
    serializer_class = ProductSerializer
    permission_classes = [PublicReadAdminWrite]
    lookup_field = "slug"

    def get_queryset(self):
        qs = super().get_queryset()
        if not self.request.user.is_staff:
            qs = qs.filter(is_active=True)
        return qs

class CustomerViewSet(viewsets.ModelViewSet):
    queryset = User.objects.filter(is_staff=False).prefetch_related("orders")
    serializer_class = UserSerializer
    permission_classes = [permissions.IsAdminUser]

class OrderViewSet(viewsets.ModelViewSet):
    queryset = Order.objects.select_related("user").prefetch_related("items__product")
    serializer_class = OrderSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        if self.request.user.is_staff:
            return qs
        if self.request.user.is_authenticated:
            return qs.filter(user=self.request.user)
        return qs.none()

    def get_permissions(self):
        if self.action in ["list", "retrieve"]:
            return [permissions.IsAuthenticated()]
        return [permissions.IsAdminUser()]

class MeAPIView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        return Response(UserSerializer(request.user).data)

class ApiLoginView(ObtainAuthToken):
    """POST username/password and receive a reusable token."""
    def post(self, request, *args, **kwargs):
        response = super().post(request, *args, **kwargs)
        token = Token.objects.get(key=response.data["token"])
        return Response({"token": token.key, "user": UserSerializer(token.user).data})


class StoreSettingsAPIView(APIView):
    permission_classes = [permissions.AllowAny]

    def get(self, request):
        return Response(StoreSettingsSerializer(StoreSettings.get_solo()).data)

    def put(self, request):
        if not request.user.is_staff:
            return Response({"detail": "Admin only."}, status=403)
        obj = StoreSettings.get_solo()
        serializer = StoreSettingsSerializer(obj, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)
