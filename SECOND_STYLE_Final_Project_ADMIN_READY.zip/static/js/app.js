const toggle = document.querySelector('[data-menu-toggle]');
const mobileNav = document.querySelector('[data-mobile-nav]');
if (toggle && mobileNav) toggle.addEventListener('click', () => mobileNav.classList.toggle('is-open'));

document.querySelectorAll('[data-dismiss]').forEach(btn => btn.addEventListener('click', () => btn.closest('.toast')?.remove()));
setTimeout(() => document.querySelectorAll('.toast').forEach(x => x.classList.add('toast-hide')), 4200);

const filterToggle = document.querySelector('[data-filter-toggle]');
const filterPanel = document.querySelector('[data-filter-panel]');
if (filterToggle && filterPanel) filterToggle.addEventListener('click', () => filterPanel.classList.toggle('is-open'));
